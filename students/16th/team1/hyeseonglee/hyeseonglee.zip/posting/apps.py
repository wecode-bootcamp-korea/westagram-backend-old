from django.apps import AppConfig


class PostingConfig(AppConfig):
    name = 'posting'
