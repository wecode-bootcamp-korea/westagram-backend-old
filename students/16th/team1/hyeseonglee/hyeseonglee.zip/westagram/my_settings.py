DATABASES = {
    'default' : {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'westagram',
        'USER': 'root',
        'PASSWORD': '1111',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}

SECRET = 'o52l^p2-ly2p(d3#jjrc#f1-*#^x+&gr^^#ev-rf#)t%h9+=fc'
ALGORITHM = 'HS256'